<?php
//Ali Elsadi
//COSC 3380 FALL 2016
//This is my work; I will not dissmeiate 
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Welcome Screen</title>
</head>


<body>
<?php
define( "DATABASE_SERVER", "localhost" );
define( "DATABASE_USERNAME", "root" );
define( "DATABASE_PASSWORD", "" );
define( "DATABASE_NAME", "Products" );
//connect to the database
$mysql = @mysql_connect(DATABASE_SERVER, DATABASE_USERNAME, DATABASE_PASSWORD) or die(mysql_error());
//select the database
mysql_select_db( DATABASE_NAME );
//asign the data passed from Flex to variables



$query = "select p.productid, p.productfinish, sum(ol.orderquantity)
    from product p, orderline ol
    where p.productid = ol.productid group by p.productid, p.productfinish
    order by p.productid";

$result = mysql_query($query);
//$result = mysql_fetch_array(mysql_query($query));
if(!$result) {
	print("Login is invalid");
}
else {
    //print(mysql_result(mysql_query($query), 0));     

    echo "<h2>Sales to Date</h2>";
    echo "<table border=1 cellpadding=5>";
    while ($row = mysql_fetch_array($result)) {
        echo "<tr><td>".($row[0])."</td>";
        echo "<td>".($row[1])."</td>";
        echo "<td>".($row[2])."</td></tr>";
    }
    echo "</table>";
}
?>

</body>